//
//  MainViewController.m
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import "MainViewController.h"
#import "CellModel.h"
#import "ShowVideoInfoViewController.h"
#import "GetVideoKeyFrameViewController.h"
#import "TrimmingVideoViewController.h"
#import "MergeVideoViewController.h"
#import "VideoEditViewController.h"

@interface MainViewController ()
@property (nonatomic, strong) NSMutableArray *tableDataSource;
@end

@implementation MainViewController

- (instancetype)init {
	self = [super init];
	if (self) {
		_tableDataSource = [[NSMutableArray alloc]init];

		CellModel *cellModel1 = [[CellModel alloc]init];
		cellModel1.title = @"获取视频信息";
		cellModel1.type = CellModelTypeShowVideoInfo;
		[_tableDataSource addObject:cellModel1];

		CellModel *cellModel2 = [[CellModel alloc]init];
		cellModel2.title = @"截取视频";
		cellModel2.type = CellModelTypeTrimmingVideo;
		[_tableDataSource addObject:cellModel2];

		CellModel *cellModel3 = [[CellModel alloc]init];
		cellModel3.title = @"给视频添加图片和文字";
		cellModel3.type = CellModelTypeVideoEdit;
		[_tableDataSource addObject:cellModel3];

		CellModel *cellModel4 = [[CellModel alloc]init];
		cellModel4.title = @"合并2个视频";
		cellModel4.type = CellModelTypeMergeVideo;
		[_tableDataSource addObject:cellModel4];

		CellModel *cellModel5 = [[CellModel alloc]init];
		cellModel5.title = @"获取视频中的关键帧";
		cellModel5.type = CellModelTypeGetVideoKeyFrame;
		[_tableDataSource addObject:cellModel5];
	}
	return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return self.tableDataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *cellIdentifier = @"UITableViewCell";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];

	if (!cell) {
		cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
	}
	CellModel *cellModel = [_tableDataSource objectAtIndex:indexPath.row];
	cell.textLabel.text = cellModel.title;
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	CellModel *cellModel = [_tableDataSource objectAtIndex:indexPath.row];

	BaseViewController *viewController;

	switch (cellModel.type) {
		case CellModelTypeShowVideoInfo: {
			viewController = [[ShowVideoInfoViewController alloc]init];
			break;
		}

		case CellModelTypeGetVideoKeyFrame: {
			viewController = [[GetVideoKeyFrameViewController alloc]init];
			break;
		}

		case CellModelTypeTrimmingVideo: {
			viewController = [[TrimmingVideoViewController alloc]init];
			break;
		}

		case CellModelTypeMergeVideo: {
			viewController = [[MergeVideoViewController alloc]init];
			break;
		}

		case CellModelTypeVideoEdit: {
			viewController = [[VideoEditViewController alloc]init];
			break;
		}
	}

	if (viewController) {
		[self.navigationController pushViewController:viewController animated:YES];
		viewController.title = cellModel.title;
	}
}

@end
