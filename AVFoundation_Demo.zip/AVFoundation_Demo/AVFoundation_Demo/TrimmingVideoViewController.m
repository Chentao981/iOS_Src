//
//  TrimmingVideoViewController.m
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import "TrimmingVideoViewController.h"
#import "MBProgressHUD+Add.h"
@interface TrimmingVideoViewController ()
@end

@implementation TrimmingVideoViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.chooseVideoButton.verticalCenter = [NSNumber numberWithFloat:0.0];
}

- (void)chooseVideoComplete:(AVURLAsset *)videoAsset {
	MBProgressHUD *messageView = [MBProgressHUD showMessag:@"正在处理中...." toView:nil];

	AVAssetExportSession *exportSession = [[AVAssetExportSession alloc] initWithAsset:videoAsset presetName:AVAssetExportPresetHighestQuality];

	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *docDir = [paths objectAtIndex:0];

	NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	NSString *destDateString = [dateFormatter stringFromDate:[[NSDate alloc]init]];

	NSString *outputUrl = [[docDir stringByAppendingPathComponent:destDateString] stringByAppendingPathExtension:@"mp4"];

	NSURL *outputFileUrl = [[NSURL alloc]initFileURLWithPath:outputUrl];

	exportSession.outputURL = outputFileUrl;
	exportSession.outputFileType = AVFileTypeQuickTimeMovie;
	CMTime start = CMTimeMakeWithSeconds(1.0, 600);
	CMTime duration = CMTimeMakeWithSeconds(3.0, 600);
	CMTimeRange range = CMTimeRangeMake(start, duration);
	exportSession.timeRange = range;

	[exportSession exportAsynchronouslyWithCompletionHandler: ^{
	    switch (exportSession.status) {
			case AVAssetExportSessionStatusCompleted: {
				dispatch_async(dispatch_get_main_queue(), ^{
					[messageView hide:YES afterDelay:0.5];
					[MBProgressHUD showSuccess:@"导出成功" detailsText:@"请在当前APP的Documents目录下查找文件" toView:nil];
				});
				break;
			}
		}
	}];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

/*
   #pragma mark - Navigation

   // In a storyboard-based application, you will often want to do a little preparation before navigation
   - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
   }
 */

@end
