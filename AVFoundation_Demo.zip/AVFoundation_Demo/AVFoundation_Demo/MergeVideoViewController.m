//
//  MergeVideoViewController.m
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import "MergeVideoViewController.h"
#import "MBProgressHUD+Add.h"
@interface MergeVideoViewController ()

@property (nonatomic, strong) NSMutableArray *videoAssets;

@end

@implementation MergeVideoViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.chooseVideoButton.verticalCenter = [NSNumber numberWithFloat:0.0];
	[self.chooseVideoButton setTitle:@"请选择2个视频" forState:UIControlStateNormal];
	// Do any additional setup after loading the view.
}

- (void)chooseVideoComplete:(AVURLAsset *)videoAsset {
	if (!_videoAssets) {
		_videoAssets = [[NSMutableArray alloc]init];
	}

	if (_videoAssets.count < 2) {
		[_videoAssets addObject:videoAsset];
	}

	//如果已经选择了2个视频 则开始合并
	if (2 == _videoAssets.count) {
		[self mergeVideos:_videoAssets];
	}
}

- (void)mergeVideos:(NSArray *)videoAssets {
	MBProgressHUD *messageView = [MBProgressHUD showMessag:@"正在处理中...." toView:nil];

	//1.创建composition
	AVMutableComposition *composition = [AVMutableComposition composition];
	AVMutableCompositionTrack *videoCompositionTrack = [composition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
	AVMutableCompositionTrack *audioCompositionTrack = [composition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];



	//2.添加asset
	AVAsset *firstVideoAsset = [videoAssets objectAtIndex:0];
	AVAsset *secondVideoAsset = [videoAssets objectAtIndex:1];


	AVAssetTrack *firstVideoAssetTrack = [[firstVideoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
	AVAssetTrack *secondVideoAssetTrack = [[secondVideoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];

	AVAssetTrack *firstAudioAssetTrack = [[firstVideoAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0];
	AVAssetTrack *secondAudioAssetTrack = [[secondVideoAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0];

	[videoCompositionTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, firstVideoAssetTrack.timeRange.duration) ofTrack:firstVideoAssetTrack atTime:kCMTimeZero error:nil];
	[videoCompositionTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, secondVideoAssetTrack.timeRange.duration) ofTrack:secondVideoAssetTrack atTime:firstVideoAssetTrack.timeRange.duration error:nil];


	[audioCompositionTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, firstVideoAssetTrack.timeRange.duration) ofTrack:firstAudioAssetTrack atTime:kCMTimeZero error:nil];
	[audioCompositionTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, secondVideoAssetTrack.timeRange.duration) ofTrack:secondAudioAssetTrack atTime:firstVideoAssetTrack.timeRange.duration error:nil];

	//3.检查视频的方向
	BOOL isFirstVideoAssetPortrait = NO;
	CGAffineTransform firstTransform = firstVideoAssetTrack.preferredTransform;
	if (firstTransform.a == 0 && firstTransform.d == 0 && (firstTransform.b == 1.0 || firstTransform.b == -1.0) && (firstTransform.c == 1.0 || firstTransform.c ==  -1.0)) {
		isFirstVideoAssetPortrait = YES;
	}

	BOOL isSecondVideoAssetPortrait = NO;
	CGAffineTransform secondTransform = secondVideoAssetTrack.preferredTransform;
	if (secondTransform.a == 0 && secondTransform.d == 0 && (secondTransform.b == 1.0 || secondTransform.b == -1.0) && (secondTransform.c == 1.0 || secondTransform.c  == -1.0)) {
		isSecondVideoAssetPortrait = YES;
	}

	if ((isFirstVideoAssetPortrait && !isSecondVideoAssetPortrait) || (!isFirstVideoAssetPortrait && isSecondVideoAssetPortrait)) {
		NSLog(@"不能把2个方向不同的视频合并");
		[messageView hide:YES afterDelay:0.5];
		[MBProgressHUD showError:@"" detailsText:@"不能把2个方向不同的视频合并" toView:nil];
		return;
	}
	//4.描述视频层并应用
	AVMutableVideoCompositionInstruction *firstVideoCompositionInstruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
	firstVideoCompositionInstruction.timeRange = CMTimeRangeMake(kCMTimeZero, firstVideoAssetTrack.timeRange.duration);

	AVMutableVideoCompositionInstruction *secondVideoCompositionInstruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
	secondVideoCompositionInstruction.timeRange = CMTimeRangeMake(firstVideoAssetTrack.timeRange.duration, CMTimeAdd(firstVideoAssetTrack.timeRange.duration, secondVideoAssetTrack.timeRange.duration));

	AVMutableVideoCompositionLayerInstruction *firstVideoLayerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoCompositionTrack];
	[firstVideoLayerInstruction setTransform:firstTransform atTime:kCMTimeZero];

	AVMutableVideoCompositionLayerInstruction *secondVideoLayerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoCompositionTrack];
	[secondVideoLayerInstruction setTransform:secondTransform atTime:firstVideoAssetTrack.timeRange.duration];

	firstVideoCompositionInstruction.layerInstructions = @[firstVideoLayerInstruction];
	secondVideoCompositionInstruction.layerInstructions = @[secondVideoLayerInstruction];

	AVMutableVideoComposition *mutableVideoComposition = [AVMutableVideoComposition videoComposition];
	mutableVideoComposition.instructions = @[firstVideoCompositionInstruction, secondVideoCompositionInstruction];

	//5.设置显示大小及帧率
	CGSize naturalSizeFirst, naturalSizeSecond;
	if (isFirstVideoAssetPortrait) {
		naturalSizeFirst = CGSizeMake(firstVideoAssetTrack.naturalSize.height, firstVideoAssetTrack.naturalSize.width);
		naturalSizeSecond = CGSizeMake(secondVideoAssetTrack.naturalSize.height, secondVideoAssetTrack.naturalSize.width);
	}
	else {
		naturalSizeFirst = firstVideoAssetTrack.naturalSize;
		naturalSizeSecond = secondVideoAssetTrack.naturalSize;
	}

	float renderWidth, renderHeight;
	if (naturalSizeFirst.width > naturalSizeSecond.width) {
		renderWidth = naturalSizeFirst.width;
	}
	else {
		renderWidth = naturalSizeSecond.width;
	}
	if (naturalSizeFirst.height > naturalSizeSecond.height) {
		renderHeight = naturalSizeFirst.height;
	}
	else {
		renderHeight = naturalSizeSecond.height;
	}

	mutableVideoComposition.renderSize = CGSizeMake(renderWidth, renderHeight);
	mutableVideoComposition.frameDuration = CMTimeMake(1, 30);

	//6.导出
	AVAssetExportSession *exporter = [[AVAssetExportSession alloc] initWithAsset:composition presetName:AVAssetExportPresetHighestQuality];

	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentDir = [paths objectAtIndex:0];


	NSDateFormatter *dateformatter = [[NSDateFormatter alloc]init];
	[dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	NSString *fileName = [dateformatter stringFromDate:[NSDate date]];

	NSString *outputFilePath = [[documentDir stringByAppendingPathComponent:fileName] stringByAppendingPathExtension:@"MOV"];
	NSURL *outputURL = [NSURL fileURLWithPath:outputFilePath];
	exporter.outputURL = outputURL;

	exporter.outputFileType = (NSString *)kUTTypeQuickTimeMovie;
	exporter.shouldOptimizeForNetworkUse = YES;
	exporter.videoComposition = mutableVideoComposition;

	[exporter exportAsynchronouslyWithCompletionHandler: ^{
	    switch (exporter.status) {
			case AVAssetExportSessionStatusCompleted: {
				dispatch_async(dispatch_get_main_queue(), ^{
					[messageView hide:YES afterDelay:0.5];
					[MBProgressHUD showSuccess:@"导出成功" detailsText:@"请在当前APP的Documents目录下查找文件" toView:nil];
				});
				break;
			}

			case AVAssetExportSessionStatusFailed: {
				NSLog(@"%@", exporter.error);
				break;
			}
		}
	}];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

@end
