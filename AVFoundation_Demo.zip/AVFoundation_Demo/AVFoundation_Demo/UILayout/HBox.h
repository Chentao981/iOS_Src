//
//  HBox.h
//  UIComponents
//
//  Created by 陈涛 on 14-9-7.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#import "Box.h"

@interface HBox : Box

@end
