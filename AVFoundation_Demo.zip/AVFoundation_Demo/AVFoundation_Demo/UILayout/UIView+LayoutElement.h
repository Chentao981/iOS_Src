//
//  UIView+LayoutElement.h
//  UIComponents
//
//  Created by 陈涛 on 14-9-7.
//  Copyright (c) 2014年 chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (LayoutElement)

@property (strong, nonatomic) NSNumber *left;
@property (strong, nonatomic) NSNumber *right;
@property (strong, nonatomic) NSNumber *top;
@property (strong, nonatomic) NSNumber *bottom;
@property (strong, nonatomic) NSNumber *verticalCenter;
@property (strong, nonatomic) NSNumber *horizontalCenter;
@property (strong, nonatomic) NSNumber *percentWidth;
@property (strong, nonatomic) NSNumber *percentHeight;

@property (nonatomic, assign) BOOL includeInLayout;


@property (nonatomic,assign) CGFloat x;
@property (nonatomic,assign) CGFloat y;
@property (nonatomic,assign) CGFloat width;
@property (nonatomic,assign) CGFloat height;

@end
