//
//  ShowVideoInfoViewController.m
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import "ShowVideoInfoViewController.h"

@interface ShowVideoInfoViewController ()
@property (nonatomic, strong) UILabel *durationLabel;
@end

@implementation ShowVideoInfoViewController

- (void)viewDidLoad {
	[super viewDidLoad];

	_durationLabel = [[UILabel alloc]init];
	_durationLabel.textAlignment = NSTextAlignmentCenter;
	_durationLabel.height = 50;
	_durationLabel.backgroundColor = [UIColor grayColor];
	_durationLabel.includeInLayout = YES;
	_durationLabel.left = [NSNumber numberWithFloat:10.0];
	_durationLabel.right = [NSNumber numberWithFloat:10.0];
	_durationLabel.verticalCenter = [NSNumber numberWithFloat:0.0];
	[self.view addSubview:_durationLabel];
}

- (void)chooseVideoComplete:(AVURLAsset *)videoAsset {
	CGSize videoSize = videoAsset.naturalSize;
	CMTime duration = videoAsset.duration;
	Float64 durationSeconds = CMTimeGetSeconds(duration);
	_durationLabel.text = [NSString stringWithFormat:@"视频时长:%0.2f秒 宽度:%0.2f 长度:%0.2f", durationSeconds, videoSize.width, videoSize.height];
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

/*
   #pragma mark - Navigation

   // In a storyboard-based application, you will often want to do a little preparation before navigation
   - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
   // Get the new view controller using [segue destinationViewController].
   // Pass the selected object to the new view controller.
   }
 */

@end
