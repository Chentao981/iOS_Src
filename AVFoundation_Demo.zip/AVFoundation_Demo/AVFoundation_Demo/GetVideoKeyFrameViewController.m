//
//  GetVideoKeyFrameViewController.m
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import "GetVideoKeyFrameViewController.h"

@interface GetVideoKeyFrameViewController ()
@property (nonatomic, strong) UIImageView *imageView;
@end

@implementation GetVideoKeyFrameViewController

- (void)viewDidLoad {
	[super viewDidLoad];

	UISlider *slider = [[UISlider alloc]init];
	[slider addTarget:self action:@selector(sliderOnChanger:) forControlEvents:UIControlEventValueChanged];
	slider.height = 30;
	slider.includeInLayout = YES;
	slider.left = [NSNumber numberWithFloat:20.0];
	slider.right = [NSNumber numberWithFloat:20.0];
	slider.bottom = [NSNumber numberWithFloat:100.0];
	[self.view addSubview:slider];
}

- (void)sliderOnChanger:(UISlider *)slider {
	AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc] initWithAsset:self.videoAsset];
	Float64 durationSeconds = CMTimeGetSeconds([self.videoAsset duration]);
	CMTime midpoint = CMTimeMakeWithSeconds(durationSeconds * slider.value, 600);
	NSError *error;
	CMTime actualTime;
	CGImageRef halfWayImage = [imageGenerator copyCGImageAtTime:midpoint actualTime:&actualTime error:&error];
	[self setImageData:halfWayImage];
}

- (void)chooseVideoComplete:(AVURLAsset *)videoAsset {
	AVAssetImageGenerator *imageGenerator = [[AVAssetImageGenerator alloc] initWithAsset:videoAsset];
	CMTime midpoint = CMTimeMakeWithSeconds(1, 600);
	NSError *error;
	CMTime actualTime;
	CGImageRef halfWayImage = [imageGenerator copyCGImageAtTime:midpoint actualTime:&actualTime error:&error];
	[self setImageData:halfWayImage];
}

- (void)setImageData:(CGImageRef)halfWayImage {
	if (halfWayImage != NULL) {
		if (!_imageView) {
			_imageView = [[UIImageView alloc]init];
			_imageView.contentMode = UIViewContentModeScaleAspectFit;
			_imageView.includeInLayout = YES;
			[self.view addSubview:_imageView];
		}
		_imageView.image = [[UIImage alloc]initWithCGImage:halfWayImage];
		_imageView.width = self.view.width;
		_imageView.height = self.view.width;
		_imageView.verticalCenter = [NSNumber numberWithFloat:0.0];

		CGImageRelease(halfWayImage);
	}
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

/*
   #pragma mark - Navigation

   // In a storyboard-based application, you will often want to do a little preparation before navigation
   - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
   // Get the new view controller using [segue destinationViewController].
   // Pass the selected object to the new view controller.
   }
 */

@end
