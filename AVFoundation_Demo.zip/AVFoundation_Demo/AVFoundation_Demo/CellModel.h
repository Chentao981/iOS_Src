//
//  CellModel.h
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef NS_ENUM (NSUInteger, CellModelType) {
	CellModelTypeShowVideoInfo,
	CellModelTypeGetVideoKeyFrame,
	CellModelTypeTrimmingVideo,
	CellModelTypeMergeVideo,
    CellModelTypeVideoEdit,
};

@interface CellModel : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) CellModelType type;

@end
