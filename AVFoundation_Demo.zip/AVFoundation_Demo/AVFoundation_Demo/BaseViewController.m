//
//  BaseViewController.m
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@end

@implementation BaseViewController

- (void)loadView {
	Group *group = [[Group alloc]init];
	self.view = group;
}

- (void)viewDidLoad {
	[super viewDidLoad];

	_chooseVideoButton = [UIButton buttonWithType:UIButtonTypeCustom];
	_chooseVideoButton.backgroundColor = [UIColor grayColor];
	[_chooseVideoButton addTarget:self action:@selector(chooseVideoButtonOnTouchHandler) forControlEvents:UIControlEventTouchUpInside];
	[_chooseVideoButton setTitle:@"选择视频文件" forState:UIControlStateNormal];
	_chooseVideoButton.height = 50.0f;
	_chooseVideoButton.includeInLayout = YES;
	_chooseVideoButton.left = [NSNumber numberWithFloat:20.0f];
	_chooseVideoButton.right = [NSNumber numberWithFloat:20.0f];
	_chooseVideoButton.bottom = [NSNumber numberWithFloat:20.0f];
	[self.view addSubview:_chooseVideoButton];
}

- (void)chooseVideoButtonOnTouchHandler {
//	NSURL *videoURL = [[NSBundle mainBundle]URLForResource:@"test" withExtension:@"mp4"];
//
//	NSDictionary *options = @{ AVURLAssetPreferPreciseDurationAndTimingKey:@YES };
//	AVURLAsset *videoAsset = [[AVURLAsset alloc]initWithURL:videoURL options:options];
//	self.videoAsset = videoAsset;
//	[self chooseVideoComplete:videoAsset];

	UIImagePickerController *picker = [[UIImagePickerController alloc] init];
	picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
	picker.mediaTypes = [[NSArray alloc] initWithObjects:@"public.movie", nil];
	picker.allowsEditing = YES;
	picker.delegate = self;
	[self presentViewController:picker animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
	NSURL *videoURL = [info objectForKey:UIImagePickerControllerMediaURL];

	NSDictionary *options = @{ AVURLAssetPreferPreciseDurationAndTimingKey:@YES };
	AVURLAsset *videoAsset = [[AVURLAsset alloc]initWithURL:videoURL options:options];
	self.videoAsset = videoAsset;
	[self chooseVideoComplete:videoAsset];
	[self dismissViewControllerAnimated:YES completion:nil];
}

- (void)chooseVideoComplete:(AVURLAsset *)videoAsset {
	self.videoAsset = videoAsset;
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

/*
   #pragma mark - Navigation

   // In a storyboard-based application, you will often want to do a little preparation before navigation
   - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
   // Get the new view controller using [segue destinationViewController].
   // Pass the selected object to the new view controller.
   }
 */

@end
