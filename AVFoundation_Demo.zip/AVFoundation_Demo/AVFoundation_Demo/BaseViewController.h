//
//  BaseViewController.h
//  AVFoundation_Demo
//
//  Created by 陈涛 on 15/4/18.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Group.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <AVFoundation/AVFoundation.h>
#import <MobileCoreServices/MobileCoreServices.h>
@interface BaseViewController : UIViewController

@property (nonatomic, strong) UIButton *chooseVideoButton;
@property (nonatomic, strong) AVURLAsset *videoAsset;

- (void)chooseVideoComplete:(AVURLAsset *)videoAsset;

@end
