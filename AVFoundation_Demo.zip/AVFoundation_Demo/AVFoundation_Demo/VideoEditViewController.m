//
//  VideoEditViewController.m
//  AVFoundation_Demo
//
//  Created by Chentao on 15/4/20.
//  Copyright (c) 2015年 chen. All rights reserved.
//

#import "VideoEditViewController.h"
#import "MBProgressHUD+Add.h"
@interface VideoEditViewController ()

@end

@implementation VideoEditViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.chooseVideoButton.verticalCenter = [NSNumber numberWithFloat:0.0];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
	[super didReceiveMemoryWarning];
	// Dispose of any resources that can be recreated.
}

- (void)chooseVideoComplete:(AVURLAsset *)videoAsset {
	//1.创建composition
	AVMutableComposition *composition = [AVMutableComposition composition];
	AVMutableCompositionTrack *videoCompositionTrack = [composition addMutableTrackWithMediaType:AVMediaTypeVideo preferredTrackID:kCMPersistentTrackID_Invalid];
	AVMutableCompositionTrack *audioCompositionTrack = [composition addMutableTrackWithMediaType:AVMediaTypeAudio preferredTrackID:kCMPersistentTrackID_Invalid];

	//2.添加asset
	AVAssetTrack *videoAssetTrack = [[videoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
	AVAssetTrack *audioAssetTrack = [[videoAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0];

	[videoCompositionTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoAssetTrack.timeRange.duration) ofTrack:videoAssetTrack atTime:kCMTimeZero error:nil];
	[audioCompositionTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoAssetTrack.timeRange.duration) ofTrack:audioAssetTrack atTime:kCMTimeZero error:nil];

	//3.描述视频层并应用
	CGAffineTransform firstTransform = videoAssetTrack.preferredTransform;

	AVMutableVideoCompositionInstruction *videoCompositionInstruction = [AVMutableVideoCompositionInstruction videoCompositionInstruction];
	videoCompositionInstruction.timeRange = CMTimeRangeMake(kCMTimeZero, videoAssetTrack.timeRange.duration);

	AVMutableVideoCompositionLayerInstruction *videoLayerInstruction = [AVMutableVideoCompositionLayerInstruction videoCompositionLayerInstructionWithAssetTrack:videoCompositionTrack];
	[videoLayerInstruction setTransform:firstTransform atTime:kCMTimeZero];

	videoCompositionInstruction.layerInstructions = @[videoLayerInstruction];

	AVMutableVideoComposition *mutableVideoComposition = [AVMutableVideoComposition videoComposition];
	mutableVideoComposition.instructions = @[videoCompositionInstruction];

	//4.设置显示大小及帧率
	float renderWidth = videoAssetTrack.naturalSize.width;
	float renderHeight = videoAssetTrack.naturalSize.height;

	if (firstTransform.a == 0 && firstTransform.d == 0 && (firstTransform.b == 1.0 || firstTransform.b == -1.0) && (firstTransform.c == 1.0 || firstTransform.c ==  -1.0)) {
		renderWidth = videoAssetTrack.naturalSize.height;
		renderHeight = videoAssetTrack.naturalSize.width;
	}



	mutableVideoComposition.renderSize = CGSizeMake(renderWidth, renderHeight);
	mutableVideoComposition.frameDuration = CMTimeMake(1, 30);

	//5.添加图片和文字
	UIImage *logoImage = [UIImage imageNamed:@"logo.png"];
	CALayer *waterMarkLayer = [CALayer layer];
	waterMarkLayer.frame = CGRectMake(0, logoImage.size.height, logoImage.size.width, logoImage.size.height);
	waterMarkLayer.contents = (id)logoImage.CGImage;

	CALayer *parentLayer = [CALayer layer];
	parentLayer.frame = CGRectMake(0, 0, renderWidth, renderHeight);

	CALayer *videoLayer = [CALayer layer];
	videoLayer.frame = CGRectMake(0, 0, renderWidth, renderHeight);

	[parentLayer addSublayer:videoLayer];
	[parentLayer addSublayer:waterMarkLayer];


	CATextLayer *textLayer = [CATextLayer layer];
	textLayer.string = @"水印文字";
	textLayer.font = (__bridge CFTypeRef)(@"Helvetica");
	textLayer.fontSize = 40.0f;
	textLayer.shadowOpacity = 0.6f;
	textLayer.backgroundColor = [UIColor clearColor].CGColor;
	textLayer.foregroundColor = [UIColor redColor].CGColor;
	textLayer.frame = CGRectMake(0, renderHeight - 100.0f, mutableVideoComposition.renderSize.width, 100.0f);
	[parentLayer addSublayer:textLayer];

	mutableVideoComposition.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];

	//6.导出
	AVAssetExportSession *exporter = [[AVAssetExportSession alloc] initWithAsset:composition presetName:AVAssetExportPresetHighestQuality];

	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentDir = [paths objectAtIndex:0];


	NSDateFormatter *dateformatter = [[NSDateFormatter alloc]init];
	[dateformatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
	NSString *fileName = [dateformatter stringFromDate:[NSDate date]];

	NSString *outputFilePath = [[documentDir stringByAppendingPathComponent:fileName] stringByAppendingPathExtension:@"MOV"];
	NSURL *outputURL = [NSURL fileURLWithPath:outputFilePath];
	exporter.outputURL = outputURL;

	exporter.outputFileType = (NSString *)kUTTypeQuickTimeMovie;
	exporter.shouldOptimizeForNetworkUse = YES;
	exporter.videoComposition = mutableVideoComposition;


	MBProgressHUD *messageView = [MBProgressHUD showMessag:@"正在处理中...." toView:nil];
	[exporter exportAsynchronouslyWithCompletionHandler: ^{
	    switch (exporter.status) {
			case AVAssetExportSessionStatusCompleted: {
				dispatch_async(dispatch_get_main_queue(), ^{
					[messageView hide:YES afterDelay:0.5];
					[MBProgressHUD showSuccess:@"导出成功" detailsText:@"请在当前APP的Documents目录下查找文件" toView:nil];
				});
				break;
			}

			case AVAssetExportSessionStatusFailed: {
				NSLog(@"%@", exporter.error);
				break;
			}
		}
	}];
}

@end
