//
//  ZYAppDelegate.h
//  ZYDrawString
//
//  Created by soufun on 15-1-9.
//  Copyright (c) 2015年 ZY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYAppDelegate : UIResponder<UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end
